package com.apes.feedbacksystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeedbacksystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
