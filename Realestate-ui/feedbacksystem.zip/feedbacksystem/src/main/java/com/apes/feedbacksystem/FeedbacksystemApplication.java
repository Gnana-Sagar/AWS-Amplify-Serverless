package com.apes.feedbacksystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeedbacksystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeedbacksystemApplication.class, args);
	}

}
