package com.apes.feedbacksystem.service;

import java.util.Optional;

import org.springframework.stereotype.Component;

import com.apes.feedbacksystem.entity.AssociateDetails;

@Component
public interface FeedbackRequestService {
	
	
	AssociateDetails sendRequest(Long employeeId);
}