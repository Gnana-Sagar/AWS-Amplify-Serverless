package com.apes.feedbacksystem.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Builder

public class AssociateDetails {
	
	@Id
    private Long associateId;
	private String associateName;
	private String associatemail;
	private String c_BManagerID;
	private String c_BManagerMailID;
	private String hiringmanagerID;
	private String hiringManagerMailID;
	
	public AssociateDetails() {}
	
	public Long getAssociateId() {
		return associateId;
	}
	public void setAssociateId(Long associateId) {
		this.associateId = associateId;
	}
	public String getAssociateName() {
		return associateName;
	}
	public void setAssociateName(String associateName) {
		this.associateName = associateName;
	}
	public String getAssociatemail() {
		return associatemail;
	}
	public void setAssociatemail(String associatemail) {
		this.associatemail = associatemail;
	}
	public String getC_BManagerID() {
		return c_BManagerID;
	}
	public void setC_BManagerID(String c_BManagerID) {
		this.c_BManagerID = c_BManagerID;
	}
	public String getC_BManagerMailID() {
		return c_BManagerMailID;
	}
	public void setC_BManagerMailID(String c_BManagerMailID) {
		this.c_BManagerMailID = c_BManagerMailID;
	}
	public String getHiringmanagerID() {
		return hiringmanagerID;
	}
	public void setHiringmanagerID(String hiringmanagerID) {
		this.hiringmanagerID = hiringmanagerID;
	}
	public String getHiringManagerMailID() {
		return hiringManagerMailID;
	}
	public void setHiringManagerMailID(String hiringManagerMailID) {
		this.hiringManagerMailID = hiringManagerMailID;
	}
	@Override
	public String toString() {
		return "AssociateDetails [associateId=" + associateId + ", associateName=" + associateName + ", associatemail="
				+ associatemail + ", c_BManagerID=" + c_BManagerID + ", c_BManagerMailID=" + c_BManagerMailID
				+ ", hiringmanagerID=" + hiringmanagerID + ", hiringManagerMailID=" + hiringManagerMailID + "]";
	}
	
	public AssociateDetails(Long associateId, String associateName, String associatemail, String c_BManagerID,
			String c_BManagerMailID, String hiringmanagerID, String hiringManagerMailID) {
		super();
		this.associateId = associateId;
		this.associateName = associateName;
		this.associatemail = associatemail;
		this.c_BManagerID = c_BManagerID;
		this.c_BManagerMailID = c_BManagerMailID;
		this.hiringmanagerID = hiringmanagerID;
		this.hiringManagerMailID = hiringManagerMailID;
	}
	
	
}
