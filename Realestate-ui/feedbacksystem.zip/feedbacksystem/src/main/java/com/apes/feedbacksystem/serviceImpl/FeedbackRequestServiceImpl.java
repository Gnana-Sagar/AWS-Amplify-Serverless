package com.apes.feedbacksystem.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.apes.feedbacksystem.entity.AssociateDetails;
import com.apes.feedbacksystem.model.Email;
import com.apes.feedbacksystem.repository.FeedbackRequestRepository;
import com.apes.feedbacksystem.service.FeedbackRequestService;


@Service
public class FeedbackRequestServiceImpl implements FeedbackRequestService {

	@Autowired 
	FeedbackRequestRepository feedbackRequestRepository;
	
	@Autowired
	EmailServiceImpl emailServiceImpl;
	
	
	@Override
	public AssociateDetails sendRequest(Long employeeId) {
		
	 AssociateDetails associateDetails=feedbackRequestRepository.findByAssociateId(employeeId);

	 String[] recipent = {associateDetails.getHiringManagerMailID(),associateDetails.getC_BManagerMailID()};
		if(associateDetails!= null) {
			Email email=new Email();
			email.setRecipients(recipent);
	        email.getSubject();
	        email.getBody();
	        emailServiceImpl.sendSimpleMessage(email);
	        }
		
	 return associateDetails;
	}
	

}
