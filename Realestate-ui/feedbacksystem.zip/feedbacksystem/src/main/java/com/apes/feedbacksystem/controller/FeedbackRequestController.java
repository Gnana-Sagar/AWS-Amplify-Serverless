package com.apes.feedbacksystem.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.apes.feedbacksystem.entity.AssociateDetails;
import com.apes.feedbacksystem.serviceImpl.FeedbackRequestServiceImpl;


@RestController
public class FeedbackRequestController {
	

	@Autowired 
	FeedbackRequestServiceImpl feedbackRequestServiceImpl;
	
	
	@GetMapping(value = "/workingstatus")
	public String checkApi() {
		return "Hello";
	}
	
	
	//userId
	@PostMapping("/requestfeedback/{employeeID}")
	public ResponseEntity<Object> requestfeedback(@PathVariable(value = "employeeID") Long employeeId)
	 {
		AssociateDetails associateDetails=feedbackRequestServiceImpl.sendRequest(employeeId);
		
	    
	     return ResponseEntity.ok().body(associateDetails.toString());
	}

}
